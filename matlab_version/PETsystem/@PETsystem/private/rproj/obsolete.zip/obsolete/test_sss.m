%
scanner_name = 'toshiba';

% inveon 3d
%
switch scanner_name
    case 'toshiba'
        xtal_attn = 0.083;
        angle_offset = 0.0;
        FOV_diameter = 600; %mm
        scanner = build_scanner(909.0, ...
                                [4.0775, 4.0775, 4.0775, 12], ...
                                [0, 0, 0], ...
                                16, 1, 40, 1, ...
                                1, angle_offset, 291);
end;

%
image_size = [128 128 1];
voxel_size = [4.0775, 4.0775, 4.0775];

%
emis_image = read_zubal_emis('nx', 128); %shepplogan(150, 150, 1); %circmask(image_size, 65, 50, 30.0);
attn_image = read_zubal_attn('nx', 128); %shepplogan(150, 150, 0); %emis_image * 0.0096; % water 511 mm^-1

tic;
S = sss(emis_image, attn_image, image_size, voxel_size, ...
        scanner.xtal_trans_location, ...
        scanner.xtal_ring_offsets, ...
        int16(scanner.xtal_pairs));
toc; 
